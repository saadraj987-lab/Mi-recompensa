Dicost – Promoción 20%

Versión corregida únicamente en la lectura del TOTAL del ticket.
El resto de la página se mantiene igual.
